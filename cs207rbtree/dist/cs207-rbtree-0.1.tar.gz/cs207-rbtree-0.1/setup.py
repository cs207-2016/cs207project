#!/usr/bin/env python3

from setuptools import setup

setup(
    name='cs207-rbtree',
    version='0.1',
    scripts=['cs207rbtree.py'],
    author='Sophie Hilgard',
    author_email='ash798@g.harvard.edu',
    url=''
)